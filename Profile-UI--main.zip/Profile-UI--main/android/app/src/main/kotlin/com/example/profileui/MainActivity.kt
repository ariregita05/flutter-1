package com.example.profileui

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
